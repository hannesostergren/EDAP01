from gym_connect_four.envs.connect_four_env import ConnectFourEnv, ResultType
